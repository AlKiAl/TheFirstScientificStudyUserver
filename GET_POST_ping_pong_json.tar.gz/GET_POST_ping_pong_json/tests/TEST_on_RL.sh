#!/bin/bash

# Проверяем наличие зависимостей
if ! command -v ab &> /dev/null; then
    echo "Error: Apache Benchmark (ab) is not installed. Please install it and try again."
    exit 1
fi


# Ждем, пока порт 8080 не станет доступным
while ! nc -z localhost 8080; do   
  sleep 0.1 # Ждем 0.1 секунды перед следующей попыткой
  echo "waiting for connection to the server"
done

ab -n 1000 -c 10 http://localhost:8080/hello  > test_10_rpc.txt 2>&1 

echo "Let's prove the fulfillment of the rate limiter, namely 10 RPS: the formula has the form (Complete requests - Non-2xx response) / [Time taken for tests], where [] is rounding up to an integer. You will get no more than 10, and with several requests you will almost certainly get 10. Non-2xx response -- number of responses with code 429"

read -p "Press enter to continue"

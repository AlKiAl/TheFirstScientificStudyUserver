#include <userver/utest/using_namespace_userver.hpp>
#include <userver/formats/json.hpp>

/// [Hello service sample - component]
#include <userver/components/minimal_server_component_list.hpp>
#include <userver/server/handlers/http_handler_base.hpp>
#include <userver/utils/daemon_run.hpp>
#include <userver/server/http/http_status.hpp>

#include <userver/server/http/http_response.hpp>

#include <iostream>
#include <string>
using namespace std;
using namespace userver;

namespace samples::echo {

formats::json::Value json_data;
formats::json::ValueBuilder builder;
	
class EchoServer final : public server::handlers::HttpHandlerBase {
 public:
 
	  // `kName` is used as the component name in static config
	  //static constexpr std::string_view kName = "handler-hello-sample";

	  // Component is valid after construction and is able to accept requests
	  using HttpHandlerBase::HttpHandlerBase; // it doesn't work without this line


	  std::string HandleRequestThrow(const server::http::HttpRequest& request, server::request::RequestContext&) const override {
	    
		  switch (request.GetMethod()) { // https://userver.tech/df/df5/namespaceserver_1_1http.html#enum-members
		    case server::http::HttpMethod::kGet:
		      return GetValue(request);
		    case server::http::HttpMethod::kPost:
		      return PostValue(request);
		    default:
		      throw server::handlers::ClientError(server::handlers::ExternalBody{
			  fmt::format("Unsupported method {}", request.GetMethod())
			  					}
			  				 );
		  }	    
	    	
	    	
	  }
	  
  private:


 	  
  std::string GetValue(const server::http::HttpRequest& request) const;
                       
  std::string PostValue(const server::http::HttpRequest& request/*, server::http::HttpResponse& response*/) const;  
  
};

}  // namespace samples::echo
/// [Hello service sample - component]


namespace samples::echo {

	
   //using namespace formats::json;

   
   string EchoServer::GetValue(const server::http::HttpRequest& request) const{
  	
  	string req = "";
  	
  	// working!
  	/*{
  	
  	  	using namespace userver::formats::json; // for: FromString
  		
	    // Пример JSON-строки
	    std::string json_string = R"(
	    {
		"ArrayKey": [
		    {"key1": "value1"},
		    {"key2": "value2"}
		]
	    }
	    )";
	    
	    
	    json_data = FromString(json_string);
	    
	    for(auto & json : json_data["ArrayKey"]){
	    
	    	req += formats::json::ToString(json) + "\n";
	    
	    }
	    		
  	
  	
  	}    */
  	    
  	
	if(json_data["ArrayKey"].IsArray()){
		return "Array";
	}
	
	if(builder["ArrayKey"].GetSize() >= 3){
		
		//builder["ArrayKey"]["id"] = 1;
		//for(const formats::json::Value & json : builder.ExtractValue()["ArrayKey"]){ // WORKING
		for(const formats::json::Value& json : builder.ExtractValue()["ArrayKey"]){ // WORKING		

			formats::json::ValueBuilder buffer = formats::json::ValueBuilder(json);
			buffer["id"] = 1;
			req += formats::json::ToString(buffer.ExtractValue()) + "\n";
									
		}
	}
	
	return req;
  	//return formats::json::ToString(builder.ExtractValue());
  	
  
  
  }
  
                       
    string EchoServer::PostValue(const server::http::HttpRequest& request/*, server::http::HttpResponse& response*/) const{
  	
  	using namespace userver::formats::json; // for: FromString
  	string str = "{}";
  	
  	 
  	if(!FromString(request.RequestBody()).HasMember("TrueKey")  ){
		request.GetHttpResponse().SetStatus(server::http::HttpStatus::kBadRequest); // https://userver.tech/da/da4/classserver_1_1http_1_1HttpResponse.html#a37c2491ab3f97febe7a0c9c6d91d9b48  	
  		return str;
  	}
  	
  	if(json_data != FromString(request.RequestBody())){

		request.GetHttpResponse().SetStatus(server::http::HttpStatus::kCreated); // https://userver.tech/da/da4/classserver_1_1http_1_1HttpResponse.html#a37c2491ab3f97febe7a0c9c6d91d9b48
	    	str = request.RequestBody();  	
	    	
  	    	json_data = formats::json::FromString(str);
		builder["ArrayKey"].PushBack(json_data); // https://userver.tech/d2/d20/md_en_2userver_2formats.html  	    	
  	}
    	
    	
    	
  	return str;
  
  }  

}


/// [Hello service sample - main]
int main(int argc, char* argv[]) {
  const auto component_list =
      components::MinimalServerComponentList().Append<samples::echo::EchoServer>("handler-hello-sample"); //components::MinimalServerComponentList().Append<samples::hello::Hello>(kName)
  return utils::DaemonMain(argc, argv, component_list);
}
/// [Hello service sample - main]


/*
psql -h localhost -p 15433 -U testsuite pg_service_template_db_1
http://127.10.0.1:8080/v1/hello?name=Tester
SELECT * FROM hello_schema.users;
*/


/*

{
  "TrueKey": "test_",
  "ArrayKey": [
    {
      "courier_type": "FOOT",
      "regions": [1, 2, 3],
      "working_hours": ["08:00-12:00", "14:00-18:00"]
    },
    {
      "courier_type": "BIKE",
      "regions": [4, 5, 6],
      "working_hours": ["09:00-13:00", "15:00-19:00"]
    }
  ]
}

*/

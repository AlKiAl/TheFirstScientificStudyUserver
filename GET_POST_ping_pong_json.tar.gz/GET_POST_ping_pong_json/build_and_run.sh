#!/bin/bash

#before starting, run: tchmod +x build_and_run.sh

# Запуск cmake
cmake .

# Сборка проекта
make

# Запуск программы с указанием конфигурационного файла
./userver_service --config static_config.yaml # > output.txt 2>&1

read -p "Press enter to continue"
# check http://localhost:8080/hello
# curl 127.0.0.1:8080/hello 
